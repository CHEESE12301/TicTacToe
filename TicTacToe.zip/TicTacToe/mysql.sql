--INSERT INTO score (playername, win, loss, plays, winrate) VALUES ('Hannah',0,1,1,0)
UPDATE score SET win = 2 WHERE playername='Jonathan'
-- SELECT * FROM score
